using System.Drawing;
using ZXing;
using ZXing.Common;
using ZXing.Windows.Compatibility;
using ScreenQR;

const string expected = "https://example.com/screenqr-test?value=中文";
var writer = new BarcodeWriter
{
    Format = BarcodeFormat.QR_CODE,
    Options = new EncodingOptions
    {
        Width = 360,
        Height = 360,
        Margin = 2,
        Hints = { [EncodeHintType.CHARACTER_SET] = "UTF-8" }
    }
};
using Bitmap qr = writer.Write(expected);
var actual = QrDecoder.Decode(qr);

if (actual != expected)
{
    Console.Error.WriteLine($"FAIL: expected '{expected}', got '{actual ?? "<null>"}'");
    return 1;
}

using var blank = new Bitmap(100, 100);
if (QrDecoder.Decode(blank) is not null)
{
    Console.Error.WriteLine("FAIL: blank image produced a false positive");
    return 1;
}

Console.WriteLine("PASS: QR decode and blank-image tests succeeded");
return 0;
