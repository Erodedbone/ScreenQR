using ZXing;
using ZXing.Common;
using ZXing.Windows.Compatibility;

namespace ScreenQR;

public static class QrDecoder
{
    public static string? Decode(Bitmap bitmap)
    {
        var reader = new ZXing.Windows.Compatibility.BarcodeReader
        {
            AutoRotate = true,
            Options = new DecodingOptions
            {
                TryHarder = true,
                PossibleFormats = new[] { BarcodeFormat.QR_CODE }
            }
        };

        return reader.Decode(bitmap)?.Text;
    }
}
