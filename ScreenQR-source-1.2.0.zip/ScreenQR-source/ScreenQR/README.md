# ScreenQR

ScreenQR 是一个面向 Windows 11 的轻量屏幕二维码识别工具。启动后常驻托盘，按 **Win + Alt + Q**，拖动框选屏幕上的二维码，识别结果会自动复制到剪贴板；HTTP/HTTPS 链接可一键用默认浏览器打开。

## 使用

1. 运行 `ScreenQR.exe`；应用进入托盘后会显示“ScreenQR 已打开”的 Windows 通知。
2. 按 **Win + Alt + Q**（默认值，或双击托盘图标）。
3. 拖动框选二维码；按 Esc 可取消。
4. 识别成功后结果已在剪贴板中。仅对 `http://` 和 `https://` 结果显示“打开链接”。
5. 右键托盘图标可退出。

## 设置快捷键和自启动

右键托盘图标，选择 **设置…**：

- 勾选一个或多个修饰键（Ctrl / Alt / Shift / Win），再选择主按键。
- 勾选“登录 Windows 后自动启动”可添加当前用户启动项，无需管理员权限。
- 快捷键配置保存在 `%LocalAppData%\ScreenQR\settings.json`。
- 自启动使用 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`，取消勾选会移除该启动项。
- 移动 `ScreenQR.exe` 后，应重新关闭再打开自启动开关，以更新程序路径。

## 从源码构建

需要 Windows 11 与 .NET 10 SDK：

```powershell
dotnet restore .\ScreenQR.csproj
dotnet build .\ScreenQR.csproj -c Release
```

生成免安装的 x64 单文件（包含运行时）：

```powershell
dotnet publish .\ScreenQR.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -o .\publish
```

## 实现与许可说明

- 本项目根据 `ottozumkeller/QR-Code-Reader` README 中公开描述的交互流程独立实现，没有复制其 AutoHotkey 源码、图像或安装资源。
- 检查时，原仓库根目录没有 `LICENSE` 文件，README 也未包含明确的代码许可授权。因此原项目按“未明确授权”处理，仅作为需求与交互参考。
- 二维码识别使用 NuGet 包 `ZXing.Net.Bindings.Windows.Compatibility` 0.16.16；ZXing.Net 代码采用 Apache License 2.0。发布目录包含 `THIRD-PARTY-NOTICES.txt`。
- ScreenQR 自有源码采用 MIT License，详见 `LICENSE`。

## 设计边界

- 仅解码 QR Code，不上传截图或识别内容，所有处理都在本机完成。
- 只把严格解析为绝对 HTTP/HTTPS URI 的结果作为可打开链接，其他协议仅复制文本。
- 当前发布产物为 Windows x64；源码可改 RID 重新发布 arm64。
