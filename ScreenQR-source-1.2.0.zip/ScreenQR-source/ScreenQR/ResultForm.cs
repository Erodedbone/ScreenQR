namespace ScreenQR;

internal sealed class ResultForm : Form
{
    internal ResultForm(string result)
    {
        Text = "ScreenQR · 识别成功";
        Icon = AppIcon.Create();
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = true;
        TopMost = true;
        ClientSize = new Size(520, 220);
        Font = new Font("Segoe UI", 10f);

        var title = new Label
        {
            Text = "二维码内容（已复制到剪贴板）",
            AutoSize = true,
            Location = new Point(18, 16)
        };
        var text = new TextBox
        {
            Text = result,
            ReadOnly = true,
            Multiline = true,
            ScrollBars = ScrollBars.Vertical,
            Location = new Point(18, 45),
            Size = new Size(484, 110)
        };
        var copy = new Button { Text = "再次复制", Location = new Point(306, 170), Size = new Size(94, 32) };
        copy.Click += (_, _) => ClipboardHelper.SetText(result);
        var close = new Button { Text = "关闭", DialogResult = DialogResult.OK, Location = new Point(408, 170), Size = new Size(94, 32) };
        AcceptButton = close;
        CancelButton = close;

        Controls.AddRange(new Control[] { title, text, copy, close });

        if (UrlHelper.TryGetHttpUrl(result, out var uri))
        {
            var open = new Button { Text = "打开链接", Location = new Point(204, 170), Size = new Size(94, 32) };
            open.Click += (_, _) => UrlHelper.Open(uri!);
            Controls.Add(open);
        }
    }
}
