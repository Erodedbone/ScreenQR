using System.Diagnostics;

namespace ScreenQR;

internal static class UrlHelper
{
    internal static bool TryGetHttpUrl(string text, out Uri? uri)
    {
        if (Uri.TryCreate(text.Trim(), UriKind.Absolute, out uri) &&
            (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps))
            return true;
        uri = null;
        return false;
    }

    internal static void Open(Uri uri) => Process.Start(new ProcessStartInfo(uri.AbsoluteUri) { UseShellExecute = true });
}
